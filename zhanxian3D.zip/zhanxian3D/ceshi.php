<?php
define('MANAGER_823', 'wo');
define('MANAGER_224', 'ai');
$zone='';
if(!$zone) exit(MANAGER_823.' '.MANAGER_224);